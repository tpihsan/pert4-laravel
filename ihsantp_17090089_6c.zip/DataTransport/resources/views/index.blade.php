<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>DATA TRANSPORT</title>
</head>
<body>
<br>
    <div class="container" style="margin-top: 80px">
         <div class="container-fluid">
                <div class="card">
                <div class="card">
                    <div class="card-header">
                        <strong>DATA TRANSPORT</strong>
                    </div>
                    <div class="card-body">
                        <a href="{{ route('datatransports.create') }}" class="btn btn-md btn-success" style="margin-bottom: 25px">Tambah Data</a>
                        <table class="table table-bordered" id="myTable" >
                            <thead>
                                <tr>
                                    <th scope="col">ID TRANSPORT</th>
                                    <th scope="col">AKOMODASI</th>
                                    <th scope="col">HARGA</th>
                                    
                                    <th scope="col">OPSI</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($datatransports as $d => $datatransport)
                                <tr>
                                  
                                    <td>{{ $datatransport->id_transport }}</td>
                                    <td>{{ $datatransport->akomodasi }}</td>
                                    <td>{{ $datatransport->harga }}</td>
                                   
                                    
                                    
                                    <td class="text-center">
                                        <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="{{ route('datatransports.destroy', $datatransport->id_transport) }}" method="POST">
                                            <a href="{{ route('datatransports.edit', $datatransport->id_transport) }}" class="btn btn-sm btn-primary">EDIT</a>
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready( function () {
          $('#myTable').DataTable();
        } );
    </script>

</body>
</html>