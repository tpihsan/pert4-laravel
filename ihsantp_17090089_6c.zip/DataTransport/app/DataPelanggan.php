<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataPasien extends Model
{

	protected $primaryKey = 'id_pelanggan';

    protected $fillable=['nama_pelanggan', 'ttl', 'umur', 'jk', 'alamat', 'tgl_datang', 'tujuan', 'nama_produk', 'nama_kosmetik'];
}