<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\DataTransport;

class DataTransportController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datatransports = DataTransport::latest()->get();
        return view('index', compact('datatransports'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $datatransport = DataTransport::create([
            'akomodasi' => $request->input('akomodasi'),
            'harga' => $request->input('harga'),
           
        ]);
        return redirect(route('datatransports.index'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(DataTransport $datatransport)
    // ada $id
    {
        return view('edit', compact('datatransport'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DataTransport $datatransport)
    // ada $id
    {
        $datatransport = DataTransport::whereid_transport($datatransport->id_transport)->update([
            'akomodasi' => $request->input('akomodasi'),
            'harga' => $request->input('harga')
            
        ]);

        return redirect(route('datatransports.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id_transport)
    {
        $datatransport = DataTransport::find($id_transport);
        $datatransport->delete();

        return redirect(route('datatransports.index'));
    }
}