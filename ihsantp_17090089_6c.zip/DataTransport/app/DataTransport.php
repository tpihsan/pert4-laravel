<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataTransport extends Model
{

	protected $primaryKey = 'id_transport';

    protected $fillable=['akomodasi', 'harga'];
}
